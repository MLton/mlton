see http://mlton.org/Stabilizers for information on this.
enter the examples/ dir and run "mlton [example-name].mlb" to compile the examples.

Directory Layout:
/cml/core-cml/ : Contains the modified CML with a Stable structure.
stable.sml : Api exposing the stable and stabilize functions
stable-graph.sml : Internal. Maintains the inter-thread dependency graph

./examples : Some examples using stabilizers
